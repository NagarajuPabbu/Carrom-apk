package com.example.carrom

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") { HomeScreen(
                        onSelect = { players -> nav.navigate("mode/$players") }
                    ) }
                    composable("mode/{players}",
                        arguments = listOf(navArgument("players") { type = NavType.IntType })
                    ) { backStack ->
                        val players = backStack.arguments?.getInt("players") ?: 2
                        ModeScreen(players) { mode ->
                            nav.navigate("game/$players/$mode")
                        }
                    }
                    composable("game/{players}/{mode}",
                        arguments = listOf(
                            navArgument("players") { type = NavType.IntType },
                            navArgument("mode") { type = NavType.IntType }
                        )
                    ) { backStack ->
                        val players = backStack.arguments?.getInt("players") ?: 2
                        val mode = backStack.arguments?.getInt("mode") ?: 0
                        GameScreen(players = players, teamMode = (mode == 1)) {
                            nav.popBackStack("home", inclusive = false)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onSelect: (Int) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F0E6)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Carrom", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Button(onClick = { onSelect(2) }, modifier = Modifier.width(220.dp)) { Text("2 Players (Individual)") }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onSelect(4) }, modifier = Modifier.width(220.dp)) { Text("4 Players") }
    }
}

@Composable
fun ModeScreen(players: Int, onModeChosen: (Int) -> Unit) {
    // for 4 players: 0 = 4 individuals, 1 = 2 vs 2
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F0E6)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (players == 4) {
            Text("Choose 4 Player Mode", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { onModeChosen(0) }, modifier = Modifier.width(260.dp)) { Text("4 Individuals") }
            Spacer(Modifier.height(12.dp))
            Button(onClick = { onModeChosen(1) }, modifier = Modifier.width(260.dp)) { Text("2 vs 2 (Opposite)") }
        } else {
            // For 2 players, mode is implicitly individual
            onModeChosen(0)
        }
    }
}

enum class CoinColor { WHITE, BLACK, RED, STRIKER }

data class Coin(
    val id: Int,
    val color: CoinColor,
    var pos: Offset,
    var vel: Offset = Offset.Zero,
    val radius: Float
)

data class Player(val id: Int, val team: Int, val coinColor: CoinColor)

@Composable
fun GameScreen(players: Int, teamMode: Boolean, onExit: () -> Unit) {
    var currentPlayerIndex by rememberSaveable { mutableStateOf(0) }
    val playerList = remember(players, teamMode) {
        when (players) {
            2 -> listOf(
                Player(0, team = 0, coinColor = CoinColor.WHITE),
                Player(1, team = 1, coinColor = CoinColor.BLACK)
            )
            4 -> if (teamMode) {
                listOf(
                    Player(0, team = 0, coinColor = CoinColor.WHITE),
                    Player(1, team = 1, coinColor = CoinColor.BLACK),
                    Player(2, team = 0, coinColor = CoinColor.WHITE),
                    Player(3, team = 1, coinColor = CoinColor.BLACK),
                )
            } else {
                listOf(
                    Player(0, team = 0, coinColor = CoinColor.WHITE),
                    Player(1, team = 1, coinColor = CoinColor.BLACK),
                    Player(2, team = 2, coinColor = CoinColor.WHITE),
                    Player(3, team = 3, coinColor = CoinColor.BLACK),
                )
            }
            else -> listOf(Player(0,0,CoinColor.WHITE), Player(1,1,CoinColor.BLACK))
        }
    }

    var scores by rememberSaveable { mutableStateOf(IntArray(playerList.size) { 0 }.toList()) }
    var teamScores by rememberSaveable { mutableStateOf(IntArray(2) { 0 }.toList()) }
    var message by rememberSaveable { mutableStateOf("Player ${currentPlayerIndex+1}'s turn") }

    // Board state
    var boardSize by remember { mutableStateOf(0f) }
    val pocketRadius = 20f
    val coinRadius = 16f
    val strikerRadius = 18f

    var coins by remember {
        mutableStateOf(buildList {
            // center arrangement: 9 white, 9 black, 1 red
            val center = Offset.Zero
            add(Coin(-1, CoinColor.RED, center, Offset.Zero, coinRadius))
            // circle arrangement
            fun ring(r: Float, count: Int, color: CoinColor) {
                repeat(count) { i ->
                    val ang = 2f * Math.PI.toFloat() * i / count
                    add(Coin(this.size, color, Offset(cos(ang)*r, sin(ang)*r), Offset.Zero, coinRadius))
                }
            }
            ring(45f, 6, CoinColor.WHITE)
            ring(80f, 6, CoinColor.BLACK)
            ring(115f, 6, CoinColor.WHITE)
            // striker (special id)
            add(Coin(-2, CoinColor.STRIKER, Offset(0f, (boardSize/2f) - 80f), Offset.Zero, strikerRadius))
        })
    }

    var strikerX by remember { mutableStateOf(0f) }
    var aiming by remember { mutableStateOf(false) }
    var aimStart by remember { mutableStateOf(Offset.Zero) }
    var aimEnd by remember { mutableStateOf(Offset.Zero) }
    var moving by remember { mutableStateOf(false) }

    // simple physics tick
    LaunchedEffect(coins, boardSize) {
        // No-op placeholder to keep recomposition happy
    }

    Column(Modifier.fillMaxSize().background(Color(0xFFF5F0E6))) {
        TopAppBar(
            title = { Text(if (teamMode && players==4) "Carrom • Teams" else "Carrom • Players") },
            actions = {
                TextButton(onClick = onExit) { Text("Exit") }
            }
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            if (teamMode && players==4) {
                Text("Team A: ${teamScores[0]}", fontWeight = FontWeight.SemiBold)
                Text("Team B: ${teamScores[1]}", fontWeight = FontWeight.SemiBold)
            } else {
                Text(scores.mapIndexed { idx, s -> "P${idx+1}: $s" }.joinToString("   "), fontWeight = FontWeight.SemiBold)
            }
        }
        Text(
            text = message,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            fontSize = 16.sp
        )
        Box(modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier
                .fillMaxHeight()
                .aspectRatio(1f)
                .padding(12.dp)
                .background(Color(0xFFD2B48C))
                .pointerInput(moving) {
                    detectDragGestures(
                        onDragStart = { if (!moving) {
                            aiming = true
                            aimStart = it
                            aimEnd = it
                        }},
                        onDrag = { _, dragAmount -> if (aiming && !moving) {
                            aimEnd += dragAmount
                        }},
                        onDragEnd = {
                            if (aiming && !moving) {
                                val dir = (aimStart - aimEnd)
                                val power = min(1600f, dir.getDistance()*8f)
                                // apply to striker
                                coins.find { it.color == CoinColor.STRIKER }?.let { s ->
                                    s.vel = Offset(dir.x, dir.y).let {
                                        if (it.getDistance()==0f) Offset.Zero else it / it.getDistance() * power
                                    }
                                    moving = true
                                }
                            }
                            aiming = false
                        }
                    )
                }
            ) {
                // set boardSize and translate to center
                boardSize = size.minDimension
                val half = boardSize/2f
                drawContext.canvas.save()
                drawContext.canvas.translate(center.x, center.y)

                // draw borders
                drawRect(Color(0xFFEED7B7), topLeft = Offset(-half, -half), size = size)
                drawRect(Color(0xFFB7895B), topLeft = Offset(-half, -half), size = size, style = Stroke(width = 12f))

                // pockets
                val corner = half - 24f
                val pockets = listOf(
                    Offset(-corner, -corner), Offset(corner, -corner),
                    Offset(-corner, corner), Offset(corner, corner)
                )
                pockets.forEach { drawCircle(Color(0xFF101010), radius = pocketRadius, center = it) }

                // baselines (simplified)
                drawLine(Color.DarkGray, Offset(-half+60f, half-80f), Offset(half-60f, half-80f), strokeWidth = 4f)
                drawLine(Color.DarkGray, Offset(-half+60f, -half+80f), Offset(half-60f, -half+80f), strokeWidth = 4f)
                drawLine(Color.DarkGray, Offset(-half+80f, -half+60f), Offset(-half+80f, half-60f), strokeWidth = 4f)
                drawLine(Color.DarkGray, Offset(half-80f, -half+60f), Offset(half-80f, half-60f), strokeWidth = 4f)

                // physics update step per frame (very simplified)
                if (moving) {
                    // integrate
                    coins.forEach { c ->
                        c.pos += c.vel * 0.016f
                        // friction
                        c.vel *= 0.985f
                        if (c.vel.getDistance() < 2f) c.vel = Offset.Zero
                    }
                    // collisions with walls
                    coins.forEach { c ->
                        val r = c.radius
                        if (c.pos.x - r < -half) { c.pos = c.pos.copy(x = -half + r); c.vel = c.vel.copy(x = -c.vel.x * 0.7f) }
                        if (c.pos.x + r > half)  { c.pos = c.pos.copy(x =  half - r); c.vel = c.vel.copy(x = -c.vel.x * 0.7f) }
                        if (c.pos.y - r < -half) { c.pos = c.pos.copy(y = -half + r); c.vel = c.vel.copy(y = -c.vel.y * 0.7f) }
                        if (c.pos.y + r > half)  { c.pos = c.pos.copy(y =  half - r); c.vel = c.vel.copy(y = -c.vel.y * 0.7f) }
                    }
                    // coin-coin collisions (naive)
                    for (i in 0 until coins.size) {
                        for (j in i+1 until coins.size) {
                            val a = coins[i]; val b = coins[j]
                            val delta = b.pos - a.pos
                            val dist = delta.getDistance()
                            val minDist = a.radius + b.radius
                            if (dist in 1f..minDist) {
                                val n = Offset(delta.x / dist, delta.y / dist)
                                val overlap = minDist - dist
                                a.pos -= n * (overlap/2f)
                                b.pos += n * (overlap/2f)
                                // elastic impulse
                                val rel = b.vel - a.vel
                                val sep = rel.x*n.x + rel.y*n.y
                                if (sep < 0f) {
                                    val jimp = -(1.2f) * sep
                                    a.vel -= n * jimp
                                    b.vel += n * jimp
                                }
                            }
                        }
                    }
                    // pockets check
                    val toRemove = mutableListOf<Coin>()
                    coins.forEach { c ->
                        if (c.color != CoinColor.STRIKER) {
                            for (p in pockets) {
                                if ((c.pos - p).getDistance() < pocketRadius) {
                                    toRemove += c
                                    val owner = when (c.color) {
                                        CoinColor.WHITE -> playerList[currentPlayerIndex].takeIf { it.coinColor==CoinColor.WHITE }
                                        CoinColor.BLACK -> playerList[currentPlayerIndex].takeIf { it.coinColor==CoinColor.BLACK }
                                        CoinColor.RED -> playerList[currentPlayerIndex]
                                        else -> null
                                    }
                                    if (owner != null) {
                                        if (teamMode && playerList.size==4) {
                                            val t = owner.team
                                            val arr = teamScores.toMutableList()
                                            arr[t] = arr[t] + if (c.color==CoinColor.RED) 3 else 1
                                            teamScores = arr
                                        } else {
                                            val arr = scores.toMutableList()
                                            arr[currentPlayerIndex] = arr[currentPlayerIndex] + if (c.color==CoinColor.RED) 3 else 1
                                            scores = arr
                                        }
                                        message = "Player ${currentPlayerIndex+1} scored!"
                                    }
                                    break
                                }
                            }
                        } else {
                            for (p in pockets) {
                                if ((c.pos - p).getDistance() < pocketRadius) {
                                    // striker foul: -1
                                    if (teamMode && playerList.size==4) {
                                        val t = playerList[currentPlayerIndex].team
                                        val arr = teamScores.toMutableList()
                                        arr[t] = max(0, arr[t]-1)
                                        teamScores = arr
                                    } else {
                                        val arr = scores.toMutableList()
                                        arr[currentPlayerIndex] = max(0, arr[currentPlayerIndex]-1)
                                        scores = arr
                                    }
                                    // reset striker
                                    c.pos = Offset(0f, half - 80f)
                                    c.vel = Offset.Zero
                                    message = "Foul! -1 point."
                                }
                            }
                        }
                    }
                    coins = coins.filter { it !in toRemove }
                    // stop condition
                    if (coins.all { it.vel == Offset.Zero }) {
                        moving = false
                        // next player unless scored last shot
                        if (!message.contains("scored")) {
                            currentPlayerIndex = (currentPlayerIndex + 1) % playerList.size
                        }
                        message = "Player ${currentPlayerIndex+1}'s turn"
                        // place striker on baseline for next player
                        coins.find { it.color==CoinColor.STRIKER }?.apply {
                            pos = when (currentPlayerIndex % 4) {
                                0 -> Offset(0f, half - 80f)
                                1 -> Offset(-half + 80f, 0f)
                                2 -> Offset(0f, -half + 80f)
                                else -> Offset(half - 80f, 0f)
                            }
                            vel = Offset.Zero
                        }
                    }
                }

                // draw coins
                coins.forEach { c ->
                    val color = when (c.color) {
                        CoinColor.WHITE -> Color(0xFFF2F2F2)
                        CoinColor.BLACK -> Color(0xFF222222)
                        CoinColor.RED -> Color(0xFFBB0000)
                        CoinColor.STRIKER -> Color(0xFF0088FF)
                    }
                    drawCircle(color, radius = c.radius, center = c.pos)
                    drawCircle(Color.Black, radius = c.radius, center = c.pos, style = Stroke(width = 2f))
                }

                // aiming line
                if (aiming && !moving) {
                    drawLine(Color.Black, start = aimStart, end = aimEnd, strokeWidth = 2f)
                }

                drawContext.canvas.restore()
            }
        }
        // Simple footer controls
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(onClick = {
                // reset board
                val center = Offset.Zero
                val list = mutableListOf<Coin>()
                list.add(Coin(-1, CoinColor.RED, center, Offset.Zero, coinRadius))
                fun ring(r: Float, count: Int, color: CoinColor) {
                    repeat(count) { i ->
                        val ang = 2f * Math.PI.toFloat() * i / count
                        list.add(Coin(list.size, color, Offset(cos(ang)*r, sin(ang)*r), Offset.Zero, coinRadius))
                    }
                }
                ring(45f, 6, CoinColor.WHITE)
                ring(80f, 6, CoinColor.BLACK)
                ring(115f, 6, CoinColor.WHITE)
                list.add(Coin(-2, CoinColor.STRIKER, Offset(0f, (boardSize/2f) - 80f), Offset.Zero, strikerRadius))
                coins = list
                currentPlayerIndex = 0
                scores = IntArray(playerList.size) { 0 }.toList()
                teamScores = IntArray(2) { 0 }.toList()
                message = "Player 1's turn"
            }) { Text("Reset") }

            Text("Drag from striker to aim & release", fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterVertically))

            Button(onClick = onExit) { Text("Home") }
        }
    }
}

// vector helpers
private operator fun Offset.plus(o: Offset) = Offset(x + o.x, y + o.y)
private operator fun Offset.minus(o: Offset) = Offset(x - o.x, y - o.y)
private operator fun Offset.times(s: Float) = Offset(x * s, y * s)
private operator fun Offset.div(s: Float) = Offset(x / s, y / s)
private fun Offset.getDistance(): Float = sqrt(x * x + y * y)